package com.hr.service;

import com.hr.model.dto.ContractTypeDTO;

import java.util.List;

public interface ContractTypeService {
    List<ContractTypeDTO> getContracts();
}

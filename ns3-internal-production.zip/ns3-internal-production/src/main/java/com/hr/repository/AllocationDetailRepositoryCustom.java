package com.hr.repository;

import com.hr.model.AllocationDetail;

public interface AllocationDetailRepositoryCustom {
    void saveAllocationDetail(AllocationDetail allocationDetail);
}
